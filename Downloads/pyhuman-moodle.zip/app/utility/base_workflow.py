from abc import abstractmethod
import json
import logging
import os
import socket
from datetime import datetime

# Configure the logger
logging.basicConfig(level=logging.INFO, format='%(message)s')

def get_local_hostname():
    """Retrieve the local hostname."""
    try:
        hostname = socket.gethostname()
        return hostname
    except Exception as e:
        return f"Error retrieving hostname: {e}"


class BaseWorkflow(object):

    @property
    def display(self):
        return 'Running Task: {}'.format(self.description)

    __slots__ = ['name', 'description', 'driver']

    @abstractmethod
    def __init__(self, name, description, driver=None):
        self.name = name
        self.description = description
        self.driver = driver

    @abstractmethod
    def action(self, extra=None):
        pass
    
    def cleanup(self):
        if self.driver is None:
            return
        self.driver.cleanup()


    def _log(self, message, status, step_name=None):
        """
        Log a workflow or workflow step in JSON format.

        Parameters:
        - workflow_name (str): Name of the workflow.
        - message (str): A message describing the event.
        - status (str): Status of the step ("start", "done", "error").
        - step_name (str, optional): Name of the current step in the workflow (default: None).
        """
        valid_statuses = {"start", "done", "error"}
        if status not in valid_statuses:
            raise ValueError(f"Invalid status: '{status}'. Valid statuses are {valid_statuses}.")
    
     
        timestamp = datetime.utcnow().isoformat()
        log_entry = {
            "timestamp": timestamp,
            "workflow_name": self.name,
            "status": status,
            "message": message,
            "hostname": get_local_hostname(),
            "pid": os.getpid(),
        }

        # Add step_name only if it's provided
        if step_name is not None:
            log_entry["step_name"] = step_name
    
        # Print out on a single line
        logging.info(json.dumps(log_entry))

        # print out as before
        if step_name:
            print(f"... {timestamp} {step_name}: {message}")
        else:
            print(f"{timestamp} {message}")

    def log_start(self, message="", step_name=None):
        self._log(message, "start", step_name)
    
    def log_success(self, message="", step_name=None):
        self._log(message, "done", step_name)

    def log_error(self, message="", step_name=None):
        self._log(message, "error", step_name)

